<?php

class comision_comando extends toba_aplicacion_comando_base 
{
			
}

?>