<?php
class comision_servicio_web extends toba_servicio_web
{
}
?>