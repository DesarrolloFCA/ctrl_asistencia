<?php
class comision_ei_esquema extends toba_ei_esquema
{
}
?>