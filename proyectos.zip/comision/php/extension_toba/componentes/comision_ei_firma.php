<?php
class comision_ei_firma extends toba_ei_firma
{
}
?>