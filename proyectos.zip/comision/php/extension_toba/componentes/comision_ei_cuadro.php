<?php
class comision_ei_cuadro extends toba_ei_cuadro
{
}
?>