<?php
class comision_ci extends toba_ci
{
}
?>