<?php
class comision_ei_archivos extends toba_ei_archivos
{
}
?>