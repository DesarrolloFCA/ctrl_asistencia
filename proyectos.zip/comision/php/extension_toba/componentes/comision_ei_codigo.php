<?php
class comision_ei_codigo extends toba_ei_codigo
{
}
?>