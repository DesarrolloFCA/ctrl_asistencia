<?php
class comision_cn extends toba_cn
{
}
?>