<?php
class comision_ei_grafico extends toba_ei_grafico
{
}
?>