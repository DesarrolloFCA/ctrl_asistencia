<?php
class comision_datos_tabla extends toba_datos_tabla
{
}
?>