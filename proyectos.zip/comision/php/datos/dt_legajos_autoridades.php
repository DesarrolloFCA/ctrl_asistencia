<?php
class dt_legajos_autoridades extends comision_datos_tabla
{
}

?>