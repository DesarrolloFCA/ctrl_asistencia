
------------------------------------------------------------
-- apex_msg
------------------------------------------------------------

--- INICIO Grupo de desarrollo 35736730
INSERT INTO apex_msg (msg, indice, proyecto, msg_tipo, descripcion_corta, mensaje_a, mensaje_b, mensaje_c, mensaje_customizable) VALUES (
	'35736730000006', --msg
	'viaja', --indice
	'comision', --proyecto
	'info', --msg_tipo
	'Viaja', --descripcion_corta
	'Si viaja fuera de la provincia de Mendoza por favor acercarse por la Oficina de  Personal de la Facultad.
Gracias', --mensaje_a
	NULL, --mensaje_b
	NULL, --mensaje_c
	NULL  --mensaje_customizable
);
--- FIN Grupo de desarrollo 35736730
