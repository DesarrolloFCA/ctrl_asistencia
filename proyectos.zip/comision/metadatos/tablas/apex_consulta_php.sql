
------------------------------------------------------------
-- apex_consulta_php
------------------------------------------------------------

--- INICIO Grupo de desarrollo 35736730
INSERT INTO apex_consulta_php (proyecto, consulta_php, clase, archivo_clase, archivo, descripcion, punto_montaje) VALUES (
	'comision', --proyecto
	'35736730000006', --consulta_php
	'consulta_mapuche', --clase
	'consulta_mapuche', --archivo_clase
	'datos/consulta/consulta_mapuche.php', --archivo
	NULL, --descripcion
	'35736730000002'  --punto_montaje
);
--- FIN Grupo de desarrollo 35736730
