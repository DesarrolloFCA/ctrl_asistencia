
------------------------------------------------------------
-- apex_fuente_datos_schemas
------------------------------------------------------------
INSERT INTO apex_fuente_datos_schemas (proyecto, fuente_datos, nombre, principal) VALUES (
	'comision', --proyecto
	'comision', --fuente_datos
	'reloj', --nombre
	'0'  --principal
);
INSERT INTO apex_fuente_datos_schemas (proyecto, fuente_datos, nombre, principal) VALUES (
	'comision', --proyecto
	'mapuche', --fuente_datos
	'uncu', --nombre
	'0'  --principal
);
